# 📷 ML Auth Code - QR Scanner

Sistema para sincronizar códigos de autorización de MercadoLibre y verificarlos escaneando QR.

## Cómo funciona

```
ML Ventas (browser)  →  Userscript extrae código  →  Worker Cloudflare (KV)
                                                            ↑
App QR Scanner (cel)  →  Escanea QR  →  Verifica contra código guardado
```

## Setup paso a paso

### 1. Worker en Cloudflare (una sola vez)

1. Ir a [Cloudflare Dashboard](https://dash.cloudflare.com) → Workers & Pages
2. Crear nuevo Worker: **`ml-auth-codes`**
3. Pegar el código de `worker-auth-codes.js`
4. Ir a **Settings → Variables → KV Namespace Bindings**
5. Crear KV namespace: `AUTH_CODES`
6. Vincular con binding name: `AUTH_CODES`
7. Deploy

El Worker queda en: `https://ml-auth-codes.rafaelassir.workers.dev`

### 2. Userscript en Tampermonkey

1. Abrir Tampermonkey → Crear nuevo script
2. Pegar el contenido de `ml-auth-code-sync.user.js`
3. Guardar

Ahora cuando abras la página de Ventas en ML:
- Detecta si estás en Mikra (rafael) o Chaya (CHAYA)
- Extrae el código de autorización
- Lo sube automáticamente al Worker
- Muestra un badge verde ✅ confirmando

### 3. App QR Scanner

Subir estos archivos a GitHub Pages (o cualquier hosting HTTPS):
- `scanner.html`
- `manifest-qr.json`
- `sw-qr.js`
- `icon-qr-192.png`
- `icon-qr-512.png`

**Importante:** La app necesita HTTPS para acceder a la cámara.

En el celular: abrir la URL → "Agregar a pantalla de inicio" → funciona como app.

## Uso diario

1. Abrí ML Ventas en la PC (una vez por día, en cada cuenta)
2. El userscript sube el código automáticamente
3. En el cel, abrí la app QR
4. Escaneá los QR de los paquetes
5. ✅ verde + beep agudo = código válido (te dice si es Mikra o Chaya)
6. ❌ rojo + beep grave = no coincide

## Archivos

```
├── worker-auth-codes.js       ← Worker Cloudflare (backend)
├── ml-auth-code-sync.user.js  ← Tampermonkey userscript
├── scanner.html               ← App QR Scanner
├── manifest-qr.json           ← PWA manifest
├── sw-qr.js                   ← Service Worker
├── icon-qr-192.png            ← Ícono PWA
├── icon-qr-512.png            ← Ícono PWA
└── README.md
```

## Notas

- Los códigos expiran a las 24 horas en el Worker (TTL)
- El código cambia cada día, así que hay que abrir ML al menos una vez por día
- La app refresca códigos automáticamente cada 5 minutos
- Funciona offline para escanear (usa los últimos códigos cargados)
- Enter en la app permite ingresar código manual si no tenés QR
